// package com.meetingrooms.booking.service;

// import org.junit.Test;

// public class BookingServiceTest{
//   @Test public void TestBookingIsAvailableWhenNotBooked 
// }